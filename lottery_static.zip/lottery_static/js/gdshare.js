/**
 * Created by Administrator on 2017/7/11.
 */
function shareFriend() {
    WeixinJSBridge.invoke('sendAppMessage',{
        "appid": appid,
        "img_url": imgUrl,
        "img_width": "120",
        "img_height": "120",
        "link": lineLink,
        "desc": descContent,
        "title": shareTitle
    }, function(res) {
        _report('send_msg', res.err_msg);
    })
}
function shareTimeline() {
    WeixinJSBridge.invoke('shareTimeline',{
        "img_url": imgUrl,
        "img_width": "120",
        "img_height": "120",
        "link": lineLink,
        "desc": descContent,
        "title": shareTimeLineTitle
    }, function(res) {
        _report('timeline', res.err_msg);
    });
}
function shareWeibo() {
    WeixinJSBridge.invoke('shareWeibo',{
        "content": descContent,
        "url": lineLink,
    }, function(res) {
        _report('weibo', res.err_msg);
    });
}

document.addEventListener('WeixinJSBridgeReady', function onBridgeReady() {

    // to friend
    WeixinJSBridge.on('menu:share:appmessage', function(argv){
        shareFriend();
    });

    // to Weixinpyq
    WeixinJSBridge.on('menu:share:timeline', function(argv){
        shareTimeline();
    });

    // to Weibo
    WeixinJSBridge.on('menu:share:weibo', function(argv){
        shareWeibo();
    });
}, false);